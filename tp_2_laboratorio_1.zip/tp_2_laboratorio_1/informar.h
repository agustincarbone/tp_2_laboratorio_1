#ifndef INFORMAR_H_INCLUDED
#define INFORMAR_H_INCLUDED

int informar_ConsultaFacturacion(Contratacion* arrayC,int limite,
              Pantalla* pantallas, int lenPantallas, char* cuit);
int informar_ListarContrataciones(Contratacion* arrayC,int limite,
              Pantalla* pantallas, int lenPantallas);

#endif // INFORMAR_H_INCLUDED
