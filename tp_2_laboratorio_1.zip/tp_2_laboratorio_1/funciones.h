#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

typedef struct
{

    char nombre[50];
    int edad;
    int estado;
    int dni;

} EPersona;

int funciones_init(EPersona array[],int limite);
int funciones_alta(EPersona array[],int limite);
int funciones_baja(EPersona array[],int limite, int id);
int funciones_mostrarOrdenado(EPersona array[],int limite, int orden);
int funciones_graficar(EPersona array[],int limite);


#endif // FUNCIONES_H_INCLUDED
