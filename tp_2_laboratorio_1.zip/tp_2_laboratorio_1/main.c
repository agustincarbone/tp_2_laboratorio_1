#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"
#include "utn.h"

#define size_array 20

int main()
{
    EPersona persona[size_array];
    int auxDNI;
    int auxOrden=0;
    int opcion=0;

    funciones_init(persona,size_array);

    do
    {
        opcion=0;
        getValidInt("\n Menu:\n 1- Agregar persona\n 2- Borrar persona\n 3- Imprimir lista ordenada por nombre\n"
                    " 4- Imprimir grafico de edades\n 5- Salir\n","\n No es una opcion valida\n",&opcion,1,5,2);
        switch(opcion)
        {
            case 1:
                funciones_alta(persona,size_array);
                break;
            case 2:
                getValidInt(" DNI? ","\n Numero invalido\n",&auxDNI,0,999999999,2);
                funciones_baja(persona,size_array,auxDNI);
                break;
            case 3:
                getValidInt(" orden?\n 0- mayor a menor\n 1-menor a mayor\n"," no es un orden valido\n",&auxOrden,0,1,2);
                funciones_mostrarOrdenado(persona,size_array,auxOrden);
                break;
            case 4:
                funciones_graficar(persona,size_array);
                break;

        }
    }while(opcion != 5);
    return 0;
}
