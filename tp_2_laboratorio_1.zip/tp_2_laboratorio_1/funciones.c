#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utn.h"
#include "funciones.h"

static int buscarLugarLibre(EPersona array[],int limite);
static int buscarPorDni(EPersona array[],int limite, int dni);
static int ordenar(EPersona array[],int limite, int orden);

/** \brief inicializa al array de estrucutras en 1, indicando que estan vacios y la edad en -1 para que no se muestre en el grafico
 *
 * \param array[] EPersona accede a los datos del array
 * \param limite int recibe el largo del array
 * \return int retorna -1 si hay error, 0 si no hay
 *
 */
int funciones_init(EPersona array[],int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            array[i].estado=1;
            array[i].edad=-1;
        }
    }
    return retorno;
}
/** \brief carga datos en las estructuras
 *
 * \param array[] EPersona accede a los datos del array
 * \param limite int recibe el largo del array
 * \return int retorna -2 si hay error con la carga del nombre, -3 con la edad, -4 con el DNI, -1 otro error o 0 si no hay error
 *
 */
int funciones_alta(EPersona array[],int limite)
{
    int retorno = -1;
    int i;
    char nombre[50];
    int edad;
    int dni;

    if(limite > 0 && array != NULL)
    {
        i = buscarLugarLibre(array,limite);
        if(i >= 0)
        {
            if(!getValidString("\nNombre? ","\nEso no es un nombre","El maximo es 50\n",nombre,50,2))
            {
                if(!getValidInt("\nEdad? ","\nEso no es una edad valida(1-100)\n",&edad,1,100,2))
                {
                    if(!getValidInt("\nDNI? ","\nEso no es un DNI\n",&dni,1,999999999,2))
                    {
                        retorno = 0;
                        strcpy(array[i].nombre,nombre);
                        array[i].edad = edad;
                        array[i].dni = dni;
                        array[i].estado = 0;
                    }
                    retorno = -4;
                }
            }
            else
            {
                retorno = -3;
            }
        }
        else
        {
            retorno = -2;
        }
    }
    return retorno;
}
/** \brief borra los datos de una persona
 *
 * \param array[] EPersona accede a los datos del array
 * \param limite int recibe el largo del array
 * \param dni int recibe el DNI que se debe buscar para borrar
 * \return int retorna -1 si no existe el DNI, 0 si se pudo borrar
 *
 */
int funciones_baja(EPersona array[],int limite, int dni)
{
    int indiceAEliminar;
    int retorno=-1;

    indiceAEliminar = buscarPorDni(array,limite,dni);
    if(indiceAEliminar>=0)
    {
        array[indiceAEliminar].estado=1;
        retorno=0;
    }
    return retorno;
}
/** \brief  mustra una lista de personas ordenada por nombre
 *
 * \param array[] EPersona accede a los datos del array
 * \param limite int recibe el largo del array
 * \param orden int recibe el numero para indicar el orden, 0 mayor a menor, 1 menor a mayor
 * \return int retorna -1 si no se pudo mostrar, 0 si se pudo
 *
 */
int funciones_mostrarOrdenado(EPersona array[],int limite,int orden)
{
    int retorno = -1;
    int i;

    ordenar(array,limite,orden);

    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].estado)
            {
                printf("nombre: %s - edad: %d - DNI: %d\n",array[i].nombre, array[i].edad, array[i].dni);
            }
        }
    }
    return retorno;
}
/** \brief genera un grafico de barras a partir de los datos cargados en el array
 *
 * \param array[] EPersona accede a los datos del array
 * \param limite int recibe el largo del array
 * \return int retorna 0
 *
 */
int funciones_graficar(EPersona array[], int limite)
{
    int rango[3]={0,0,0};
    int i;
    int j;
    int max=0;

    for(i=0;i<limite;i++)
    {
        if(array[i].edad<18 && array[i].edad>0)
        {
            rango[0]++;
        }else if(array[i].edad>17 && array[i].edad<35)
            {
                rango[1]++;
            }else if(array[i].edad>35)
                {
                    rango[2]++;
                }
    }

    for(i=0;i<3;i++)
    {
        if(rango[i]>max)
            max=rango[i];
    }

    for(i=max;i>0;i--)
    {
        for(j=0;j<3;j++)
        {
            if(j>0)
                printf("    ");

            if(rango[j]>=i)
            {
                printf("    *");
            }else
            {
                printf("     ");
            }
        }
        printf("\n");
    }
    printf("    <18    18-35    >35");

    return 0;
}
/** \brief busca un lugar libre en el array para guardar los datos del alta
 *
 * \param array[] EPersona accede a los datos del array
 * \param limite int recibe el largo del array
 * \return int retorna -1 si no hay lugar, o el numero del espacio libre
 *
 */
int buscarLugarLibre(EPersona array[],int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(array[i].estado)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}
/** \brief ordena la lista de personas por el nombre
 *
 * \param array[] EPersona accede a los datos del array
 * \param limite int recibe el largo del array
 * \param orden int recibe el numero para indicar el orden, 0 mayor a menor, 1 menor a mayor
 * \return int retorna -1 si hubo problemas al ordenar, 0 si no hubo error
 *
 */
int ordenar(EPersona array[],int limite, int orden)
{
    int retorno = -1;
    int i;
    int flagSwap;
    EPersona auxEstructura;

    if(limite > 0 && array != NULL)
    {
        do
        {
            flagSwap = 0;
            for(i=0;i<limite-1;i++)
            {
                if(!array[i].estado && !array[i+1].estado)
                {
                    if((strcmp(array[i].nombre,array[i+1].nombre) > 0 && orden) || (strcmp(array[i].nombre,array[i+1].nombre) < 0 && !orden)) //******
                    {
                        auxEstructura = array[i];
                        array[i] = array[i+1];
                        array[i+1] = auxEstructura;
                        flagSwap = 1;
                    }
                }
            }
        }while(flagSwap);
        retorno = 0;
    }
    return retorno;
}
/** \brief busca un DNI en las estructuras cargadas en el array
 *
 * \param array[] EPersona accede a los datos del array
 * \param limite int recibe el largo del array
 * \param dni int recibe el DNI a buscar
 * \return int retorna -1 si no se encontro el DNI, 0 si se encontro
 *
 */
int buscarPorDni(EPersona array[],int limite, int dni)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(!array[i].estado && array[i].dni==dni)
            {
                retorno=i;
                break;
            }
        }
    }
    return retorno;
}

